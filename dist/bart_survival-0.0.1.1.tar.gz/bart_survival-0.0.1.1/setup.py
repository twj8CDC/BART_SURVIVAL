from setuptools import setup, find_packages

setup(
    name='bart_survival',
    version='0.0.1.1',
    install_requires=[
        "arviz",
        "numpy",
        "scipy",
        "sksurv",
        "pymc_experimental",
        "typing",
        "pathlib",
        "pymc",
        "pymc_bart",
        "xarray",
        "pytensor"
        "cloudpickle"
        # 'requests',
        # 'importlib-metadata; python_version<"3.10"',
    ],
    packages=find_packages(
        # All keyword arguments below are optional:
        where='src',
        include=[
            'simulation.py',
            "surv_bart.py"
        ],  
        exclude=['tests'],  # empty by default
    )
    
    # include_package_data=True,

)