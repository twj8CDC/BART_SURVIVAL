def test():
    """test module
    """    
    print("hi")